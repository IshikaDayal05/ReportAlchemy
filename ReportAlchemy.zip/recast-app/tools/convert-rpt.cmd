@echo off
rem Converts Crystal Reports .rpt files to the XML that Recast reads, using RptToXml
rem (https://github.com/ajryan/RptToXml). Needs Windows and the SAP Crystal Reports runtime.
setlocal
cd /d "%~dp0"
where RptToXml.exe >nul 2>nul
if errorlevel 1 if not exist "RptToXml.exe" (
  echo.
  echo   RptToXml.exe was not found. Download it from https://github.com/ajryan/RptToXml
  echo   and put it in this folder or on your PATH, then run this file again.
  echo.
  pause
  exit /b 1
)
set /p SRC=Folder containing your .rpt files: 
for %%F in ("%SRC%\*.rpt") do (
  echo Converting %%~nxF
  RptToXml.exe "%%F" "%%~dpnF.xml"
)
echo.
echo Done. Drop the .xml files into Recast.
pause
