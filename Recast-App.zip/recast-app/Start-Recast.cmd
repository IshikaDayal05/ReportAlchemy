@echo off
setlocal
cd /d "%~dp0"
if not exist "bin\server.mjs" (
  echo.
  echo   The app files are missing, so this was most likely started from
  echo   inside the ZIP file.
  echo.
  echo   Do this instead:
  echo     1. Right-click Recast-App.zip  -^>  "Extract All..."  -^>  Extract
  echo     2. Open the folder it creates
  echo     3. Double-click Start-Recast.cmd in THAT folder
  echo.
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js is not installed.
  echo   Install Node 24 LTS from https://nodejs.org then run this file again.
  echo.
  pause
  exit /b 1
)
echo.
echo   Starting Recast...  the browser opens automatically.
echo   Keep this window open. Close it to stop the app.
echo.
node bin\server.mjs --serve-dist --open
pause
