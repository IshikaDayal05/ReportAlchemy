#!/bin/sh
cd "$(dirname "$0")"
if [ ! -f bin/server.mjs ]; then
  echo ""
  echo "  The app files are missing, so this was most likely started from"
  echo "  inside the ZIP file."
  echo ""
  echo "  Unzip Recast-App.zip first, then run this file from the folder"
  echo "  it creates."
  echo ""
  exit 1
fi
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Node.js is not installed."
  echo "  Install Node 24 LTS from https://nodejs.org then run this file again."
  echo ""
  exit 1
fi
echo ""
echo "  Starting Recast...  the browser opens automatically."
echo "  Keep this window open. Press Ctrl+C to stop the app."
echo ""
node bin/server.mjs --serve-dist --open
